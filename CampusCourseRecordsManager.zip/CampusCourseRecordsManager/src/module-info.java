/**
 * 
 */
/**
 * 
 */
module CampusCourseRecordsManager {
}