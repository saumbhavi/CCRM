// File: edu/ccrm/config/AppConfig.java
package edu.ccrm.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

/**
 * Singleton class for application configuration
 * Demonstrates Singleton pattern, static blocks, exception handling
 */
public class AppConfig {
    
    // Singleton instance
    private static AppConfig instance;
    
    // Configuration properties
    private Properties properties;
    private Path dataDirectory;
    private Path backupDirectory;
    private DateTimeFormatter dateFormatter;
    
    // Constants (demonstrates static final)
    public static final String APP_NAME = "Campus Course & Records Manager";
    public static final String VERSION = "1.0.0";
    public static final int MAX_LOGIN_ATTEMPTS = 3;
    
    // Private constructor for Singleton
    private AppConfig() {
        loadConfiguration();
        initializeDirectories();
    }
    
    // Static method to get Singleton instance
    public static AppConfig getInstance() {
        if (instance == null) {
            synchronized (AppConfig.class) {
                if (instance == null) {
                    instance = new AppConfig();
                }
            }
        }
        return instance;
    }
    
    // Static initialization block
    static {
        System.out.println("🚀 " + APP_NAME + " v" + VERSION + " Initializing...");
    }
    
    private void loadConfiguration() {
        properties = new Properties();
        
        try {
            // Load default properties
            properties.setProperty("data.dir", "data");
            properties.setProperty("backup.dir", "backups");
            properties.setProperty("date.format", "yyyy-MM-dd_HH-mm-ss");
            properties.setProperty("max.backup.files", "10");
            properties.setProperty("auto.backup", "true");
            
            // Try to load from external config file (if exists)
            Path configFile = Paths.get("config.properties");
            if (Files.exists(configFile)) {
                properties.load(Files.newInputStream(configFile));
                System.out.println("✓ Loaded configuration from: " + configFile.toAbsolutePath());
            } else {
                System.out.println("⚠ Using default configuration. Create 'config.properties' to customize.");
            }
            
        } catch (IOException e) {
            System.err.println("❌ Error loading configuration: " + e.getMessage());
            // Continue with defaults
        }
    }
    
    private void initializeDirectories() {
        try {
            // Create data directory
            dataDirectory = Paths.get(properties.getProperty("data.dir"));
            if (!Files.exists(dataDirectory)) {
                Files.createDirectories(dataDirectory);
                System.out.println("✓ Created data directory: " + dataDirectory.toAbsolutePath());
            }
            
            // Create backup directory
            backupDirectory = Paths.get(properties.getProperty("backup.dir"));
            if (!Files.exists(backupDirectory)) {
                Files.createDirectories(backupDirectory);
                System.out.println("✓ Created backup directory: " + backupDirectory.toAbsolutePath());
            }
            
            // Initialize date formatter
            dateFormatter = DateTimeFormatter.ofPattern(properties.getProperty("date.format"));
            
        } catch (IOException e) {
            throw new RuntimeException("Failed to initialize application directories", e);
        }
    }
    
    // Getters for configuration properties
    public Path getDataDirectory() {
        return dataDirectory;
    }
    
    public Path getBackupDirectory() {
        return backupDirectory;
    }
    
    public DateTimeFormatter getDateFormatter() {
        return dateFormatter;
    }
    
    public String getProperty(String key) {
        return properties.getProperty(key);
    }
    
    public int getIntProperty(String key) {
        try {
            return Integer.parseInt(properties.getProperty(key));
        } catch (NumberFormatException e) {
            System.err.println("Invalid integer property for key: " + key);
            return 0;
        }
    }
    
    public boolean getBooleanProperty(String key) {
        return Boolean.parseBoolean(properties.getProperty(key));
    }
    
    // Method to reload configuration (demonstrates instance method)
    public void reloadConfiguration() {
        synchronized (this) {
            loadConfiguration();
            initializeDirectories();
            System.out.println("✓ Configuration reloaded");
        }
    }
    
    // Utility method to display configuration (demonstrates StringBuilder)
    public String displayConfiguration() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n=== Application Configuration ===\n");
        sb.append("Application: ").append(APP_NAME).append(" v").append(VERSION).append("\n");
        sb.append("Data Directory: ").append(dataDirectory.toAbsolutePath()).append("\n");
        sb.append("Backup Directory: ").append(backupDirectory.toAbsolutePath()).append("\n");
        sb.append("Date Format: ").append(properties.getProperty("date.format")).append("\n");
        sb.append("Max Backup Files: ").append(getIntProperty("max.backup.files")).append("\n");
        sb.append("Auto Backup: ").append(getBooleanProperty("auto.backup")).append("\n");
        
        return sb.toString();
    }
    
    // Override clone to prevent cloning (Singleton protection)
    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException("Singleton instance cannot be cloned");
    }
}