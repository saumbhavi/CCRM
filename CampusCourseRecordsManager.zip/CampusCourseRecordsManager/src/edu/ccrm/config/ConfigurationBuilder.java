// File: edu/ccrm/config/ConfigurationBuilder.java
package edu.ccrm.config;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Builder pattern for configuration (alternative to properties file)
 * Demonstrates Builder pattern, method chaining
 */
public class ConfigurationBuilder {
    private Properties properties = new Properties();
    
    public ConfigurationBuilder dataDirectory(String path) {
        properties.setProperty("data.dir", path);
        return this;
    }
    
    public ConfigurationBuilder backupDirectory(String path) {
        properties.setProperty("backup.dir", path);
        return this;
    }
    
    public ConfigurationBuilder dateFormat(String format) {
        properties.setProperty("date.format", format);
        return this;
    }
    
    public ConfigurationBuilder maxBackupFiles(int maxFiles) {
        properties.setProperty("max.backup.files", String.valueOf(maxFiles));
        return this;
    }
    
    public ConfigurationBuilder autoBackup(boolean enabled) {
        properties.setProperty("auto.backup", String.valueOf(enabled));
        return this;
    }
    
    public Properties build() {
        // Validate configuration
        if (!properties.containsKey("data.dir")) {
            properties.setProperty("data.dir", "data");
        }
        if (!properties.containsKey("backup.dir")) {
            properties.setProperty("backup.dir", "backups");
        }
        
        return properties;
    }
    
    // Static factory method
    public static ConfigurationBuilder create() {
        return new ConfigurationBuilder();
    }
}