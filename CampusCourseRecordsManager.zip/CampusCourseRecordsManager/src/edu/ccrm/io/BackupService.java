// File: edu/ccrm/io/BackupService.java
package edu.ccrm.io;

import edu.ccrm.config.AppConfig;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;

/**
 * Handles backup operations with recursive file operations
 * Demonstrates recursion, Files.walk(), and advanced NIO.2 features
 */
public class BackupService {
    private final AppConfig config;
    private final ImportExportService importExportService;
    
    public BackupService() {
        this.config = AppConfig.getInstance();
        this.importExportService = new ImportExportService();
    }
    
    // ================= BACKUP OPERATIONS =================
    
    public void createBackup() throws IOException {
        LocalDateTime now = LocalDateTime.now();
        String timestamp = now.format(config.getDateFormatter());
        Path backupDir = config.getBackupDirectory().resolve("backup_" + timestamp);
        
        // Create backup directory
        Files.createDirectories(backupDir);
        System.out.println("📦 Creating backup in: " + backupDir.getFileName());
        
        // Export current data to backup directory
        Path studentsBackup = backupDir.resolve("students.csv");
        Path coursesBackup = backupDir.resolve("courses.csv");
        
        // First export to temporary files, then move to backup
        importExportService.exportStudentsToCSV();
        importExportService.exportCoursesToCSV();
        
        // Move exported files to backup directory
        Path currentStudents = config.getDataDirectory().resolve("students_export.csv");
        Path currentCourses = config.getDataDirectory().resolve("courses_export.csv");
        
        if (Files.exists(currentStudents)) {
            Files.move(currentStudents, studentsBackup, StandardCopyOption.REPLACE_EXISTING);
        }
        if (Files.exists(currentCourses)) {
            Files.move(currentCourses, coursesBackup, StandardCopyOption.REPLACE_EXISTING);
        }
        
        // Create backup info file
        createBackupInfoFile(backupDir, now);
        
        System.out.println("✅ Backup created successfully!");
        System.out.println("📍 Location: " + backupDir.toAbsolutePath());
        
        // Show backup size using recursive method
        long totalSize = calculateDirectorySize(backupDir);
        System.out.printf("💾 Backup size: %.2f KB%n", totalSize / 1024.0);
    }
    
    public void listBackups() throws IOException {
        Path backupDir = config.getBackupDirectory();
        
        if (!Files.exists(backupDir)) {
            System.out.println("📁 No backups directory found.");
            return;
        }
        
        System.out.println("\n📂 AVAILABLE BACKUPS:");
        
        // Use Files.list() with try-with-resources
        try (Stream<Path> backups = Files.list(backupDir)) {
            backups.filter(Files::isDirectory)
                  .filter(path -> path.getFileName().toString().startsWith("backup_"))
                  .sorted()
                  .forEach(backup -> {
                      try {
                          long size = calculateDirectorySize(backup);
                          String modified = Files.getLastModifiedTime(backup).toString();
                          System.out.printf("• %s (%.2f KB, %s)%n", 
                              backup.getFileName(), size / 1024.0, modified);
                      } catch (IOException e) {
                          System.out.println("• " + backup.getFileName() + " [Error reading info]");
                      }
                  });
        }
    }
    
    // ================= RECURSIVE OPERATIONS =================
    
    /**
     * Recursively calculates directory size
     * Demonstrates recursion and Files.walk()
     */
    public long calculateDirectorySize(Path directory) throws IOException {
        if (!Files.exists(directory) || !Files.isDirectory(directory)) {
            return 0;
        }
        
        // Using AtomicLong for mutable long in lambda
        AtomicLong totalSize = new AtomicLong(0);
        
        // Recursive approach using Files.walk()
        try (Stream<Path> files = Files.walk(directory)) {
            files.filter(Files::isRegularFile)
                 .forEach(file -> {
                     try {
                         totalSize.addAndGet(Files.size(file));
                     } catch (IOException e) {
                         System.err.println("Error reading file size: " + file);
                     }
                 });
        }
        
        return totalSize.get();
    }
    
    /**
     * Alternative recursive implementation without Streams
     * Demonstrates traditional recursion
     */
    public long calculateDirectorySizeRecursive(Path directory) {
        if (!Files.exists(directory) || !Files.isDirectory(directory)) {
            return 0;
        }
        
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
            long totalSize = 0;
            
            for (Path entry : stream) {
                if (Files.isDirectory(entry)) {
                    // Recursive call for subdirectories
                    totalSize += calculateDirectorySizeRecursive(entry);
                } else {
                    totalSize += Files.size(entry);
                }
            }
            return totalSize;
            
        } catch (IOException e) {
            System.err.println("Error calculating size for: " + directory);
            return 0;
        }
    }
    
    /**
     * Recursively list files with indentation by depth
     * Demonstrates depth-based recursion
     */
    public void listFilesRecursively(Path directory, int depth) throws IOException {
        if (!Files.exists(directory)) return;
        
        String indent = "  ".repeat(depth);
        
        try (Stream<Path> entries = Files.list(directory)) {
            entries.sorted()
                   .forEach(entry -> {
                       try {
                           if (Files.isDirectory(entry)) {
                               System.out.println(indent + "📁 " + entry.getFileName() + "/");
                               // Recursive call with increased depth
                               listFilesRecursively(entry, depth + 1);
                           } else {
                               long size = Files.size(entry);
                               System.out.printf("%s📄 %s (%.2f KB)%n", 
                                   indent, entry.getFileName(), size / 1024.0);
                           }
                       } catch (IOException e) {
                           System.out.println(indent + "❌ Error reading: " + entry.getFileName());
                       }
                   });
        }
    }
    
    public void displayBackupHierarchy() throws IOException {
        Path backupDir = config.getBackupDirectory();
        System.out.println("\n🌳 BACKUP DIRECTORY HIERARCHY:");
        System.out.println(backupDir.toAbsolutePath() + "/");
        listFilesRecursively(backupDir, 1);
    }
    
    // ================= UTILITY METHODS =================
    
    private void createBackupInfoFile(Path backupDir, LocalDateTime backupTime) throws IOException {
        Path infoFile = backupDir.resolve("backup_info.txt");
        
        String info = String.format(
            "CCRM Backup Information\n" +
            "=======================\n" +
            "Backup Time: %s\n" +
            "Application: %s v%s\n" +
            "Total Students: %d\n" +
            "Total Courses: %d\n" +
            "Backup Format: CSV\n",
            backupTime.format(config.getDateFormatter()),
            AppConfig.APP_NAME,
            AppConfig.VERSION,
            0, // Would be actual counts in real implementation
            0
        );
        
        Files.writeString(infoFile, info);
    }
    
    public void cleanupOldBackups(int keepCount) throws IOException {
        Path backupDir = config.getBackupDirectory();
        
        if (!Files.exists(backupDir)) return;
        
        try (Stream<Path> backups = Files.list(backupDir)) {
            List<Path> backupList = backups.filter(Files::isDirectory)
                                          .filter(path -> path.getFileName().toString().startsWith("backup_"))
                                          .sorted()
                                          .collect(Collectors.toList());
            
            if (backupList.size() > keepCount) {
                int deleteCount = backupList.size() - keepCount;
                System.out.println("🗑️  Deleting " + deleteCount + " old backup(s)...");
                
                for (int i = 0; i < deleteCount; i++) {
                    deleteDirectoryRecursive(backupList.get(i));
                    System.out.println("✅ Deleted: " + backupList.get(i).getFileName());
                }
            } else {
                System.out.println("✅ No old backups to clean up.");
            }
        }
    }
    
    /**
     * Recursively delete directory
     * Demonstrates recursive file deletion
     */
    private void deleteDirectoryRecursive(Path directory) throws IOException {
        if (!Files.exists(directory)) return;
        
        // First delete all files in directory
        try (Stream<Path> files = Files.walk(directory)) {
            files.sorted((a, b) -> -a.compareTo(b)) // Reverse order for deletion
                 .forEach(path -> {
                     try {
                         Files.delete(path);
                     } catch (IOException e) {
                         System.err.println("Failed to delete: " + path);
                     }
                 });
        }
    }
}