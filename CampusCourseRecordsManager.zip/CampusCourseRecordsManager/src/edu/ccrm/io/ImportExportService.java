// File: edu/ccrm/io/ImportExportService.java
package edu.ccrm.io;

import edu.ccrm.config.AppConfig;
import edu.ccrm.domain.*;
import edu.ccrm.service.StudentService;
import edu.ccrm.service.CourseService;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Handles CSV import/export using NIO.2 and Streams API
 * Demonstrates Files.lines(), Stream pipelines, and NIO.2 operations
 */
public class ImportExportService {
    private final AppConfig config;
    private final StudentService studentService;
    private final CourseService courseService;
    
    public ImportExportService() {
        this.config = AppConfig.getInstance();
        this.studentService = StudentService.getInstance();
        this.courseService = CourseService.getInstance();
    }
    
    // ================= EXPORT OPERATIONS =================
    
    public void exportStudentsToCSV() throws IOException {
        Path exportFile = config.getDataDirectory().resolve("students_export.csv");
        
        // Create CSV header
        String header = "ID,RegistrationNo,FullName,Email,Status,CreatedAt,GPA\n";
        
        // Create CSV lines using Stream API
        List<String> lines = studentService.getAllStudents().stream()
            .map(student -> String.format("%s,%s,%s,%s,%s,%s,%.2f",
                escapeCsv(student.getId()),
                escapeCsv(student.getRegNo()),
                escapeCsv(student.getFullName()),
                escapeCsv(student.getEmail()),
                student.isActive(),
                student.getCreatedAt().format(config.getDateFormatter()),
                student.calculateGPA()))
            .collect(Collectors.toList());
        
        // Write to file using NIO.2
        Files.write(exportFile, Arrays.asList(header));
        Files.write(exportFile, lines, StandardOpenOption.APPEND);
        
        System.out.println("✅ Students exported to: " + exportFile.toAbsolutePath());
        System.out.println("📊 Total records: " + lines.size());
    }
    
    public void exportCoursesToCSV() throws IOException {
        Path exportFile = config.getDataDirectory().resolve("courses_export.csv");
        
        String header = "Code,Title,Credits,Instructor,Department,Active\n";
        
        List<String> lines = courseService.getAllCourses().stream()
            .map(course -> String.format("%s,%s,%d,%s,%s,%s",
                escapeCsv(course.getCode()),
                escapeCsv(course.getTitle()),
                course.getCredits(),
                escapeCsv(course.getInstructor()),
                escapeCsv(course.getDepartment().name()),
                course.isActive()))
            .collect(Collectors.toList());
        
        Files.write(exportFile, Arrays.asList(header));
        Files.write(exportFile, lines, StandardOpenOption.APPEND);
        
        System.out.println("✅ Courses exported to: " + exportFile.toAbsolutePath());
        System.out.println("📊 Total records: " + lines.size());
    }
    
    // ================= IMPORT OPERATIONS =================
    
    public void importStudentsFromCSV(Path csvFile) throws IOException {
        if (!Files.exists(csvFile)) {
            throw new IOException("File not found: " + csvFile);
        }
        
        System.out.println("📥 Importing students from: " + csvFile.getFileName());
        
        // Use Stream API with Files.lines() for efficient reading
        long importedCount = 0;
        long errorCount = 0;
        
        try (Stream<String> lines = Files.lines(csvFile)) {
            importedCount = lines
                .skip(1) // Skip header
                .filter(line -> !line.trim().isEmpty()) // Skip empty lines
                .map(this::parseStudentFromCsv)
                .filter(student -> {
                    if (student != null) {
                        try {
                            studentService.save(student);
                            return true;
                        } catch (Exception e) {
                            System.out.println("❌ Error importing student: " + e.getMessage());
                            errorCount++;
                            return false;
                        }
                    }
                    errorCount++;
                    return false;
                })
                .count();
        }
        
        System.out.printf("✅ Import completed: %d successful, %d errors%n", importedCount, errorCount);
    }
    
    public void importCoursesFromCSV(Path csvFile) throws IOException {
        if (!Files.exists(csvFile)) {
            throw new IOException("File not found: " + csvFile);
        }
        
        System.out.println("📥 Importing courses from: " + csvFile.getFileName());
        
        long importedCount = 0;
        long errorCount = 0;
        
        try (Stream<String> lines = Files.lines(csvFile)) {
            importedCount = lines
                .skip(1)
                .filter(line -> !line.trim().isEmpty())
                .map(this::parseCourseFromCsv)
                .filter(course -> {
                    if (course != null) {
                        try {
                            courseService.save(course);
                            return true;
                        } catch (Exception e) {
                            System.out.println("❌ Error importing course: " + e.getMessage());
                            errorCount++;
                            return false;
                        }
                    }
                    errorCount++;
                    return false;
                })
                .count();
        }
        
        System.out.printf("✅ Import completed: %d successful, %d errors%n", importedCount, errorCount);
    }
    
    // ================= CSV PARSING METHODS =================
    
    private Student parseStudentFromCsv(String csvLine) {
        try {
            String[] fields = parseCsvLine(csvLine);
            
            if (fields.length < 4) {
                System.out.println("❌ Invalid student record: " + csvLine);
                return null;
            }
            
            String id = fields[0].trim();
            String regNo = fields[1].trim();
            String fullName = fields[2].trim();
            String email = fields[3].trim();
            
            // Validate required fields
            if (id.isEmpty() || regNo.isEmpty() || fullName.isEmpty()) {
                System.out.println("❌ Missing required fields in: " + csvLine);
                return null;
            }
            
            return new Student(id, regNo, fullName, email);
            
        } catch (Exception e) {
            System.out.println("❌ Error parsing student CSV line: " + csvLine);
            return null;
        }
    }
    
    private Course parseCourseFromCsv(String csvLine) {
        try {
            String[] fields = parseCsvLine(csvLine);
            
            if (fields.length < 5) {
                System.out.println("❌ Invalid course record: " + csvLine);
                return null;
            }
            
            String code = fields[0].trim();
            String title = fields[1].trim();
            int credits = Integer.parseInt(fields[2].trim());
            String instructor = fields[3].trim();
            Department department = Department.valueOf(fields[4].trim().toUpperCase());
            
            return new Course.Builder()
                .code(code)
                .title(title)
                .credits(credits)
                .instructor(instructor)
                .department(department)
                .build();
            
        } catch (Exception e) {
            System.out.println("❌ Error parsing course CSV line: " + csvLine + " - " + e.getMessage());
            return null;
        }
    }
    
    // ================= UTILITY METHODS =================
    
    private String[] parseCsvLine(String line) {
        // Simple CSV parser that handles quoted fields
        return Arrays.stream(line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1))
            .map(field -> field.replace("\"", "").trim())
            .toArray(String[]::new);
    }
    
    private String escapeCsv(String field) {
        if (field == null) return "";
        // Add quotes if field contains comma or quotes
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            return "\"" + field.replace("\"", "\"\"") + "\"";
        }
        return field;
    }
    
    // ================= FILE UTILITIES =================
    
    public void listDataFiles() throws IOException {
        Path dataDir = config.getDataDirectory();
        
        if (!Files.exists(dataDir)) {
            System.out.println("📁 Data directory does not exist: " + dataDir);
            return;
        }
        
        System.out.println("\n📁 FILES IN DATA DIRECTORY:");
        
        // Use Files.list() with Stream for directory listing
        try (Stream<Path> files = Files.list(dataDir)) {
            files.filter(Files::isRegularFile)
                .sorted()
                .forEach(file -> {
                    try {
                        long size = Files.size(file);
                        System.out.printf("• %s (%.2f KB)%n", 
                            file.getFileName(), size / 1024.0);
                    } catch (IOException e) {
                        System.out.println("• " + file.getFileName() + " [Error reading size]");
                    }
                });
        }
    }
    
    public boolean deleteDataFile(String filename) throws IOException {
        Path file = config.getDataDirectory().resolve(filename);
        
        if (!Files.exists(file)) {
            System.out.println("❌ File not found: " + filename);
            return false;
        }
        
        // Confirm deletion
        System.out.print("⚠ Are you sure you want to delete " + filename + "? (y/n): ");
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        String confirmation = scanner.nextLine().trim().toLowerCase();
        
        if (confirmation.equals("y") || confirmation.equals("yes")) {
            Files.delete(file);
            System.out.println("✅ File deleted: " + filename);
            return true;
        } else {
            System.out.println("❌ Deletion cancelled.");
            return false;
        }
    }
}