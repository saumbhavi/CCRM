package edu.ccrm.domain;

import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private String regNo;
    private List<Enrollment> enrollments;

    public Student(String id, String regNo, String fullName, String email) {
        super(id, fullName, email);
        this.regNo = regNo;
        this.enrollments = new ArrayList<>();
    }

    @Override
    public String getRole() {
        return "Student";
    }

    // Getters and Setters
    public String getRegNo() { return regNo; }
    public void setRegNo(String regNo) { this.regNo = regNo; }

    public List<Enrollment> getEnrollments() { return enrollments; }

    public void enrollInCourse(Course course, Semester semester) {
        Enrollment enrollment = new Enrollment(this, course, semester);
        this.enrollments.add(enrollment);
    }

    public void unenrollFromCourse(Course course) {
        enrollments.removeIf(e -> e.getCourse().equals(course));
    }

    public double calculateGPA() {
        if (enrollments.isEmpty()) return 0.0;
        
        double totalPoints = 0.0;
        int totalCredits = 0;
        
        for (Enrollment enrollment : enrollments) {
            if (enrollment.getGrade() != null) {
                totalPoints += enrollment.getGrade().getPoints() * enrollment.getCourse().getCredits();
                totalCredits += enrollment.getCourse().getCredits();
            }
        }
        
        return totalCredits > 0 ? totalPoints / totalCredits : 0.0;
    }

    @Override
    public String toString() {
        return String.format("%s, RegNo: %s, GPA: %.2f", 
            super.toString(), regNo, calculateGPA());
    }
}