package edu.ccrm.domain;

import java.time.LocalDateTime;

public class Enrollment {
    private Student student;
    private Course course;
    private Semester semester;
    private Grade grade;
    private Double marks;
    private LocalDateTime enrolledAt;

    public Enrollment(Student student, Course course, Semester semester) {
        this.student = student;
        this.course = course;
        this.semester = semester;
        this.enrolledAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public Semester getSemester() { return semester; }
    public Grade getGrade() { return grade; }
    public Double getMarks() { return marks; }
    public LocalDateTime getEnrolledAt() { return enrolledAt; }

    public void recordGrade(double marks) {
        this.marks = marks;
        this.grade = Grade.fromScore(marks);
    }

    @Override
    public String toString() {
        return String.format("Course: %s, Semester: %s, Marks: %s, Grade: %s",
            course.getCode(), semester, marks != null ? marks : "N/A", 
            grade != null ? grade : "N/A");
    }
}