package edu.ccrm.domain;

public class Course {
    private final String code;  // Immutable
    private String title;
    private int credits;
    private String instructor;
    private Department department;
    private boolean active;

    // Private constructor for Builder
    private Course(Builder builder) {
        this.code = builder.code;
        this.title = builder.title;
        this.credits = builder.credits;
        this.instructor = builder.instructor;
        this.department = builder.department;
        this.active = true;
    }

    // Builder Pattern (Inner static class)
    public static class Builder {
        private String code;
        private String title;
        private int credits;
        private String instructor;
        private Department department;

        public Builder code(String code) {
            this.code = code;
            return this;
        }

        public Builder title(String title) {
            this.title = title;
            return this;
        }

        public Builder credits(int credits) {
            this.credits = credits;
            return this;
        }

        public Builder instructor(String instructor) {
            this.instructor = instructor;
            return this;
        }

        public Builder department(Department department) {
            this.department = department;
            return this;
        }

        public Course build() {
            // Validation
            if (code == null || title == null || credits <= 0) {
                throw new IllegalArgumentException("Course code, title, and credits are required");
            }
            return new Course(this);
        }
    }

    // Getters only (immutable for code)
    public String getCode() { return code; }
    public String getTitle() { return title; }
    public int getCredits() { return credits; }
    public String getInstructor() { return instructor; }
    public Department getDepartment() { return department; }
    public boolean isActive() { return active; }

    // Setters (where mutable)
    public void setTitle(String title) { this.title = title; }
    public void setCredits(int credits) { this.credits = credits; }
    public void setInstructor(String instructor) { this.instructor = instructor; }
    public void setDepartment(Department department) { this.department = department; }
    public void setActive(boolean active) { this.active = active; }

    @Override
    public String toString() {
        return String.format("Code: %s, Title: %s, Credits: %d, Instructor: %s, Department: %s",
            code, title, credits, instructor, department);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Course course = (Course) obj;
        return code.equals(course.code);
    }

    @Override
    public int hashCode() {
        return code.hashCode();
    }
}