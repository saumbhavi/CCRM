// File: edu/ccrm/util/TestDataGenerator.java
package edu.ccrm.util;

import edu.ccrm.domain.*;
import edu.ccrm.service.StudentService;
import edu.ccrm.service.CourseService;

/**
 * Utility class to generate test data
 * Demonstrates static methods, arrays, and utility patterns
 */
public class TestDataGenerator {
    
    public static void generateSampleData() {
        System.out.println("📦 Generating sample data...");
        
        StudentService studentService = StudentService.getInstance();
        CourseService courseService = CourseService.getInstance();
        
        // Create sample courses using Builder pattern
        Course[] courses = {
            new Course.Builder().code("CS101").title("Introduction to Programming")
                .credits(3).instructor("Dr. Smith").department(Department.COMPUTER_SCIENCE).build(),
                
            new Course.Builder().code("MATH201").title("Calculus I")
                .credits(4).instructor("Prof. Johnson").department(Department.MATHEMATICS).build(),
                
            new Course.Builder().code("PHY101").title("Physics Fundamentals")
                .credits(3).instructor("Dr. Brown").department(Department.PHYSICS).build()
        };
        
        // Save courses using enhanced for loop
        for (Course course : courses) {
            try {
                courseService.save(course);
            } catch (Exception e) {
                System.out.println("⚠ Could not save course: " + course.getCode());
            }
        }
        
        // Create sample students
        Student[] students = {
            new Student("S001", "2023001", "Alice Johnson", "alice@university.edu"),
            new Student("S002", "2023002", "Bob Smith", "bob@university.edu"),
            new Student("S003", "2023003", "Carol Davis", "carol@university.edu")
        };
        
        // Save students using traditional for loop
        for (int i = 0; i < students.length; i++) {
            try {
                studentService.save(students[i]);
                // Enroll in first course
                studentService.enrollStudentInCourse(students[i].getId(), courses[0], Semester.SPRING);
            } catch (Exception e) {
                System.out.println("⚠ Could not save student: " + students[i].getFullName());
            }
        }
        
        System.out.println("✅ Sample data generated successfully!");
    }
}