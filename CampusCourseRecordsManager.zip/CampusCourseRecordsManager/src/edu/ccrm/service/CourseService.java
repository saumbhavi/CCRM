// File: edu/ccrm/service/CourseService.java
package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.Department;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import edu.ccrm.service.exceptions.DuplicateCourseException;
import edu.ccrm.service.exceptions.CourseNotFoundException;

public class CourseService implements Searchable<Course>, Persistable<Course> {
    
    private List<Course> courses = new ArrayList<>();
    private static CourseService instance;
    
    private CourseService() {}
    
    public static CourseService getInstance() {
        if (instance == null) {
            instance = new CourseService();
        }
        return instance;
    }
    
    @Override
    public void save(Course course) {
        if (course == null) {
            throw new IllegalArgumentException("Course cannot be null");
        }
        
        if (exists(course.getCode())) {
            throw new DuplicateCourseException("Course with code " + course.getCode() + " already exists");
        }
        
        courses.add(course);
        System.out.println("Course saved: " + course.getCode());
    }
    
    @Override
    public void delete(String code) {
        boolean removed = courses.removeIf(course -> course.getCode().equals(code));
        if (removed) {
            System.out.println("Course deleted: " + code);
        } else {
            throw new CourseNotFoundException("Course with code " + code + " not found");
        }
    }
    
    @Override
    public Course findById(String code) {
        return courses.stream()
                .filter(course -> course.getCode().equals(code))
                .findFirst()
                .orElse(null);
    }
    
    @Override
    public List<Course> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return new ArrayList<>(courses);
        }
        
        String lowerKeyword = keyword.toLowerCase();
        return courses.stream()
                .filter(course -> 
                    course.getCode().toLowerCase().contains(lowerKeyword) ||
                    course.getTitle().toLowerCase().contains(lowerKeyword) ||
                    course.getInstructor().toLowerCase().contains(lowerKeyword))
                .collect(Collectors.toList());
    }
    
    // Advanced search with filters (Stream API demonstration)
    public List<Course> searchByDepartment(Department department) {
        return courses.stream()
                .filter(course -> course.getDepartment() == department)
                .collect(Collectors.toList());
    }
    
    public List<Course> searchByInstructor(String instructor) {
        return courses.stream()
                .filter(course -> course.getInstructor().equalsIgnoreCase(instructor))
                .collect(Collectors.toList());
    }
    
    public List<Course> getActiveCourses() {
        return courses.stream()
                .filter(Course::isActive)
                .collect(Collectors.toList());
    }
    
    public List<Course> getAllCourses() {
        return new ArrayList<>(courses);
    }
}