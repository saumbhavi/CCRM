// File: edu/ccrm/service/Persistable.java
package edu.ccrm.service;

/**
 * Interface for persistence operations
 * Demonstrates interface with default methods
 */
public interface Persistable<T> {
    void save(T item);
    void delete(String id);
    T findById(String id);
    
    // Default method (Java 8+ feature)
    default boolean exists(String id) {
        return findById(id) != null;
    }
}