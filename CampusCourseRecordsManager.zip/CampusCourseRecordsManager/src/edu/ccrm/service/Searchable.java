package edu.ccrm.service;

import java.util.List;

/**
 * Generic interface for search operations
 * Demonstrates generics and functional interface
 */
@FunctionalInterface
public interface Searchable<T> {
    List<T> search(String keyword);
}