// File: edu/ccrm/service/exceptions/CourseNotFoundException.java
package edu.ccrm.service.exceptions;

public class CourseNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 6L;  // Unique ID
    
    public CourseNotFoundException(String message) {
        super(message);
    }
}