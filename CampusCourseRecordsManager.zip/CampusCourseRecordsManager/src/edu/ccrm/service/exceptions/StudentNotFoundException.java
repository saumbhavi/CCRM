// File: edu/ccrm/service/exceptions/StudentNotFoundException.java
package edu.ccrm.service.exceptions;

public class StudentNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 2L;  // Unique ID
    
    public StudentNotFoundException(String message) {
        super(message);
    }
}