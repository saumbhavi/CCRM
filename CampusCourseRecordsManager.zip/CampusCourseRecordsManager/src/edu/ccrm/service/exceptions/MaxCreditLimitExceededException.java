// File: edu/ccrm/service/exceptions/MaxCreditLimitExceededException.java
package edu.ccrm.service.exceptions;

public class MaxCreditLimitExceededException extends RuntimeException {
    private static final long serialVersionUID = 4L;  // Unique ID
    
    public MaxCreditLimitExceededException(String message) {
        super(message);
    }
}