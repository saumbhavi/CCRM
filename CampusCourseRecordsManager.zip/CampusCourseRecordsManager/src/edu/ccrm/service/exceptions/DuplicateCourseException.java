// File: edu/ccrm/service/exceptions/DuplicateCourseException.java
package edu.ccrm.service.exceptions;

public class DuplicateCourseException extends RuntimeException {
    private static final long serialVersionUID = 5L;  // Unique ID
    
    public DuplicateCourseException(String message) {
        super(message);
    }
}