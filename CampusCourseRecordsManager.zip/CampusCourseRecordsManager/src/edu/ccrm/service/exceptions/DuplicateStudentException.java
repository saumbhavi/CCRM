// File: edu/ccrm/service/exceptions/DuplicateStudentException.java
package edu.ccrm.service.exceptions;

public class DuplicateStudentException extends RuntimeException {
    private static final long serialVersionUID = 1L;  // Added serialVersionUID
    
    public DuplicateStudentException(String message) {
        super(message);
    }
}