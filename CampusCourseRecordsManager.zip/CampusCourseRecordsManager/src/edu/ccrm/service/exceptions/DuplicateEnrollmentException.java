// File: edu/ccrm/service/exceptions/DuplicateEnrollmentException.java
package edu.ccrm.service.exceptions;

public class DuplicateEnrollmentException extends RuntimeException {
    private static final long serialVersionUID = 3L;  // Unique ID
    
    public DuplicateEnrollmentException(String message) {
        super(message);
    }
}