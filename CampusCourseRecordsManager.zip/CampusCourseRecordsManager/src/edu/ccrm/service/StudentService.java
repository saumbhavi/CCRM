// File: edu/ccrm/service/StudentService.java
package edu.ccrm.service;

import edu.ccrm.domain.Student;
import edu.ccrm.service.exceptions.DuplicateStudentException;
import edu.ccrm.domain.Course;
import edu.ccrm.domain.Semester;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import edu.ccrm.service.exceptions.StudentNotFoundException;
import edu.ccrm.service.exceptions.DuplicateEnrollmentException;
import edu.ccrm.service.exceptions.MaxCreditLimitExceededException;
import edu.ccrm.service.exceptions.CourseNotFoundException;

/**
 * Service class for student operations
 * Demonstrates Stream API, Lambda expressions, Exception handling
 */
public class StudentService implements Searchable<Student>, Persistable<Student> {
    
    private List<Student> students = new ArrayList<>();
    private static final int MAX_CREDITS_PER_SEMESTER = 18;
    
    // Singleton pattern (we'll enhance this later)
    private static StudentService instance;
    
    private StudentService() {} // Private constructor for Singleton
    
    public static StudentService getInstance() {
        if (instance == null) {
            instance = new StudentService();
        }
        return instance;
    }
    
    // Persistable interface implementation
    @Override
    public void save(Student student) {
        if (student == null) {
            throw new IllegalArgumentException("Student cannot be null");
        }
        
        // Check for duplicate ID
        if (exists(student.getId())) {
            throw new DuplicateStudentException("Student with ID " + student.getId() + " already exists");
        }
        
        students.add(student);
        System.out.println("Student saved: " + student.getFullName());
    }
    
    @Override
    public void delete(String id) {
        boolean removed = students.removeIf(student -> student.getId().equals(id));
        if (removed) {
            System.out.println("Student deleted: " + id);
        } else {
            throw new StudentNotFoundException("Student with ID " + id + " not found");
        }
    }
    
    @Override
    public Student findById(String id) {
        return students.stream()
                .filter(student -> student.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
    
    // Searchable interface implementation
    @Override
    public List<Student> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return new ArrayList<>(students);
        }
        
        String lowerKeyword = keyword.toLowerCase();
        return students.stream()
                .filter(student -> 
                    student.getFullName().toLowerCase().contains(lowerKeyword) ||
                    student.getEmail().toLowerCase().contains(lowerKeyword) ||
                    student.getRegNo().toLowerCase().contains(lowerKeyword))
                .collect(Collectors.toList());
    }
    
    // Business logic methods
    public void enrollStudentInCourse(String studentId, Course course, Semester semester) {
        Student student = findById(studentId);
        if (student == null) {
            throw new StudentNotFoundException("Student not found: " + studentId);
        }
        
        if (!student.isActive()) {
            throw new IllegalStateException("Cannot enroll inactive student");
        }
        
        // Check credit limit using Streams
        int currentCredits = student.getEnrollments().stream()
                .filter(e -> e.getSemester() == semester)
                .mapToInt(e -> e.getCourse().getCredits())
                .sum();
        
        if (currentCredits + course.getCredits() > MAX_CREDITS_PER_SEMESTER) {
            throw new MaxCreditLimitExceededException(
                "Credit limit exceeded. Current: " + currentCredits + 
                ", Attempting: " + course.getCredits() + 
                ", Max: " + MAX_CREDITS_PER_SEMESTER);
        }
        
        // Check if already enrolled
        boolean alreadyEnrolled = student.getEnrollments().stream()
                .anyMatch(e -> e.getCourse().equals(course) && e.getSemester() == semester);
        
        if (alreadyEnrolled) {
            throw new DuplicateEnrollmentException("Student already enrolled in this course for " + semester);
        }
        
        student.enrollInCourse(course, semester);
        System.out.println("Student " + student.getFullName() + " enrolled in " + course.getCode());
    }
    
    public void recordGrade(String studentId, String courseCode, double marks) {
        Student student = findById(studentId);
        if (student == null) {
            throw new StudentNotFoundException("Student not found: " + studentId);
        }
        
        student.getEnrollments().stream()
                .filter(e -> e.getCourse().getCode().equals(courseCode))
                .findFirst()
                .ifPresentOrElse(
                    enrollment -> {
                        enrollment.recordGrade(marks);
                        System.out.println("Grade recorded: " + enrollment.getGrade() + " for " + courseCode);
                    },
                    () -> { throw new CourseNotFoundException("Student not enrolled in course: " + courseCode); }
                );
    }
    
    // Additional service methods
    public List<Student> getStudentsByGpa(double minGpa) {
        return students.stream()
                .filter(student -> student.calculateGPA() >= minGpa)
                .sorted((s1, s2) -> Double.compare(s2.calculateGPA(), s1.calculateGPA())) // Descending
                .collect(Collectors.toList());
    }
    
    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }
    
    public long getActiveStudentCount() {
        return students.stream()
                .filter(Student::isActive)
                .count();
    }
}