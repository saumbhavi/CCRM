// File: edu/ccrm/Main.java
package edu.ccrm;

import edu.ccrm.cli.CCRMCLI;
import edu.ccrm.config.AppConfig;

/**
 * Main class to bootstrap the application
 * Demonstrates main method, exception handling, and program flow
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("🎯 Starting Campus Course & Records Manager...");
        
        try {
            // Initialize configuration (Singleton)
            AppConfig config = AppConfig.getInstance();
            
            // Start CLI interface
            CCRMCLI cli = new CCRMCLI();
            cli.start();
            
        } catch (Exception e) {
            System.err.println("💥 Critical error starting application: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
        
        System.out.println("✅ Application shutdown completed successfully.");
    }
}