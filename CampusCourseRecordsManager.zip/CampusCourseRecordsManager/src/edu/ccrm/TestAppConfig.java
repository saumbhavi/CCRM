// File: edu/ccrm/TestAppConfig.java
package edu.ccrm;

import edu.ccrm.config.AppConfig;

/**
 * Test class for Singleton AppConfig
 * Demonstrates Singleton pattern verification
 */
public class TestAppConfig {
    public static void main(String[] args) {
        System.out.println("=== Testing Singleton AppConfig ===\n");
        
        // Get Singleton instance multiple times
        AppConfig config1 = AppConfig.getInstance();
        AppConfig config2 = AppConfig.getInstance();
        
        // Verify it's the same instance (Singleton test)
        System.out.println("Singleton Test:");
        System.out.println("config1 == config2: " + (config1 == config2));
        System.out.println("config1 hashCode: " + config1.hashCode());
        System.out.println("config2 hashCode: " + config2.hashCode());
        
        // Display configuration
        System.out.println(config1.displayConfiguration());
        
        // Test configuration properties
        System.out.println("=== Configuration Properties ===");
        System.out.println("Data Directory: " + config1.getDataDirectory());
        System.out.println("Backup Directory: " + config1.getBackupDirectory());
        System.out.println("Max Login Attempts: " + AppConfig.MAX_LOGIN_ATTEMPTS);
        
        // Test Builder pattern
        testConfigurationBuilder();
    }
    
    private static void testConfigurationBuilder() {
        System.out.println("\n=== Testing ConfigurationBuilder ===");
        
        var builder = edu.ccrm.config.ConfigurationBuilder.create()
            .dataDirectory("custom_data")
            .backupDirectory("custom_backups")
            .dateFormat("dd-MM-yyyy")
            .maxBackupFiles(5)
            .autoBackup(false);
        
        var properties = builder.build();
        System.out.println("Custom Data Dir: " + properties.getProperty("data.dir"));
        System.out.println("Custom Backup Dir: " + properties.getProperty("backup.dir"));
        System.out.println("Max Backup Files: " + properties.getProperty("max.backup.files"));
    }
}