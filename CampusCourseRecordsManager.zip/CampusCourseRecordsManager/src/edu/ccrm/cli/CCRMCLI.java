// File: edu/ccrm/cli/CCRMCLI.java
package edu.ccrm.cli;

import edu.ccrm.config.AppConfig;
import edu.ccrm.domain.*;
import edu.ccrm.service.StudentService;
import edu.ccrm.service.CourseService;
import edu.ccrm.service.exceptions.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

import edu.ccrm.io.ImportExportService;
import edu.ccrm.io.BackupService;
import java.nio.file.Paths;

/**
 * Main CLI controller demonstrating:
 * - Enhanced switch expressions (Java 14+)
 * - All loop types (while, do-while, for, enhanced for)
 * - Break, continue, labeled jumps
 * - Decision structures (if-else, nested if)
 */
public class CCRMCLI {
    private final Scanner scanner;
    private final StudentService studentService;
    private final CourseService courseService;
    private final AppConfig config;
    
    private boolean running = true;
    
    public CCRMCLI() {
        this.scanner = new Scanner(System.in);
        this.studentService = StudentService.getInstance();
        this.courseService = CourseService.getInstance();
        this.config = AppConfig.getInstance();
    }
    
    public void start() {
        displayWelcomeMessage();
        
        // Main application loop (do-while demonstration)
        do {
            displayMainMenu();
            int choice = getIntInput("Enter your choice: ");
            processMainMenuChoice(choice);
        } while (running);
        
        shutdown();
    }
    
    private void displayWelcomeMessage() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("🚀 " + AppConfig.APP_NAME + " v" + AppConfig.VERSION);
        System.out.println("📅 Started at: " + LocalDateTime.now().format(config.getDateFormatter()));
        System.out.println("=".repeat(60));
        System.out.println(config.displayConfiguration());
    }
    
    private void displayMainMenu() {
        System.out.println("\n" + "═".repeat(50));
        System.out.println("🏠 MAIN MENU");
        System.out.println("═".repeat(50));
        System.out.println("1. 👨‍🎓 Student Management");
        System.out.println("2. 📚 Course Management");
        System.out.println("3. 📝 Enrollment & Grading");
        System.out.println("4. 💾 Import/Export Data");
        System.out.println("5. 🗂️ Backup & Utilities");
        System.out.println("6. 📊 Reports & Analytics");
        System.out.println("7. ℹ️ Java Platform Info");
        System.out.println("0. ❌ Exit");
        System.out.println("═".repeat(50));
    }
    
    // Enhanced switch expression (Java 14+ feature)
    private void processMainMenuChoice(int choice) {
        switch (choice) {
            case 1 -> manageStudents();
            case 2 -> manageCourses();
            case 3 -> manageEnrollments();
            case 4 -> manageDataIO();
            case 5 -> manageBackup();
            case 6 -> showReports();
            case 7 -> showJavaInfo();
            case 0 -> running = false;
            default -> System.out.println("❌ Invalid choice! Please try again.");
        }
    }
    
    // ================= STUDENT MANAGEMENT =================
    private void manageStudents() {
        studentManagementLoop: // Label for labeled break
        while (true) {
            System.out.println("\n" + "─".repeat(40));
            System.out.println("👨‍🎓 STUDENT MANAGEMENT");
            System.out.println("─".repeat(40));
            System.out.println("1. Add Student");
            System.out.println("2. List All Students");
            System.out.println("3. Search Students");
            System.out.println("4. Update Student");
            System.out.println("5. Deactivate Student");
            System.out.println("6. View Student Transcript");
            System.out.println("0. ← Back to Main Menu");
            
            int choice = getIntInput("Choose option: ");
            
            switch (choice) {
                case 1 -> addStudent();
                case 2 -> listAllStudents();
                case 3 -> searchStudents();
                case 4 -> updateStudent();
                case 5 -> deactivateStudent();
                case 6 -> viewStudentTranscript();
                case 0 -> { break studentManagementLoop; } // Labeled break
                default -> System.out.println("❌ Invalid choice!");
            }
        }
    }
    
    private void addStudent() {
        System.out.println("\n➕ ADD NEW STUDENT");
        
        String id = getStringInput("Student ID: ");
        String regNo = getStringInput("Registration Number: ");
        String fullName = getStringInput("Full Name: ");
        String email = getStringInput("Email: ");
        
        try {
            Student student = new Student(id, regNo, fullName, email);
            studentService.save(student);
            System.out.println("✅ Student added successfully!");
        } catch (DuplicateStudentException e) {
            System.out.println("❌ Error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Validation error: " + e.getMessage());
        }
    }
    
    private void listAllStudents() {
        System.out.println("\n📋 ALL STUDENTS");
        List<Student> students = studentService.getAllStudents();
        
        if (students.isEmpty()) {
            System.out.println("No students found.");
            return;
        }
        
        // Enhanced for loop demonstration
        int count = 1;
        for (Student student : students) {
            System.out.printf("%d. %s (GPA: %.2f)%n", count++, student, student.calculateGPA());
        }
        
        System.out.printf("\nTotal students: %d%n", students.size());
        System.out.printf("Active students: %d%n", studentService.getActiveStudentCount());
    }
    
    private void searchStudents() {
        String keyword = getStringInput("Enter search keyword: ");
        List<Student> results = studentService.search(keyword);
        
        System.out.println("\n🔍 SEARCH RESULTS");
        if (results.isEmpty()) {
            System.out.println("No students found matching: " + keyword);
        } else {
            // Traditional for loop with index
            for (int i = 0; i < results.size(); i++) {
                Student student = results.get(i);
                System.out.printf("%d. %s%n", i + 1, student);
            }
        }
    }
    
    // ================= COURSE MANAGEMENT =================
    private void manageCourses() {
        while (true) {
            System.out.println("\n" + "─".repeat(40));
            System.out.println("📚 COURSE MANAGEMENT");
            System.out.println("─".repeat(40));
            System.out.println("1. Add Course");
            System.out.println("2. List All Courses");
            System.out.println("3. Search Courses");
            System.out.println("4. Search by Department");
            System.out.println("5. Search by Instructor");
            System.out.println("0. ← Back to Main Menu");
            
            int choice = getIntInput("Choose option: ");
            
            switch (choice) {
                case 1 -> addCourse();
                case 2 -> listAllCourses();
                case 3 -> searchCourses();
                case 4 -> searchCoursesByDepartment();
                case 5 -> searchCoursesByInstructor();
                case 0 -> { return; } // Unlabeled return
                default -> System.out.println("❌ Invalid choice!");
            }
        }
    }
    
    private void addCourse() {
        System.out.println("\n➕ ADD NEW COURSE");
        
        // Demonstrate Builder pattern in CLI
        String code = getStringInput("Course Code: ");
        String title = getStringInput("Course Title: ");
        int credits = getIntInput("Credits: ");
        String instructor = getStringInput("Instructor: ");
        
        // Display departments for selection
        System.out.println("\nAvailable Departments:");
        Department[] departments = Department.values();
        for (int i = 0; i < departments.length; i++) {
            System.out.printf("%d. %s%n", i + 1, departments[i].getDisplayName());
        }
        
        int deptChoice = getIntInput("Select department (1-" + departments.length + "): ") - 1;
        
        if (deptChoice < 0 || deptChoice >= departments.length) {
            System.out.println("❌ Invalid department selection!");
            return;
        }
        
        try {
            Course course = new Course.Builder()
                .code(code)
                .title(title)
                .credits(credits)
                .instructor(instructor)
                .department(departments[deptChoice])
                .build();
            
            courseService.save(course);
            System.out.println("✅ Course added successfully!");
            
        } catch (IllegalArgumentException | DuplicateCourseException e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }
    
    private void listAllCourses() {
        System.out.println("\n📋 ALL COURSES");
        List<Course> courses = courseService.getAllCourses();
        
        if (courses.isEmpty()) {
            System.out.println("No courses found.");
            return;
        }
        
        // Enhanced for loop with continue demonstration
        int activeCount = 0;
        for (Course course : courses) {
            if (!course.isActive()) {
                continue; // Skip inactive courses
            }
            System.out.printf("• %s%n", course);
            activeCount++;
        }
        
        System.out.printf("\nActive courses: %d/%d%n", activeCount, courses.size());
    }
    
    // ================= ENROLLMENT & GRADING =================
    private void manageEnrollments() {
        System.out.println("\n📝 ENROLLMENT & GRADING");
        // Implementation will be added in next steps
        System.out.println("🚧 Feature coming soon!");
    }
    
    // ================= OTHER MANAGEMENT METHODS =================
    private void manageDataIO() {
        System.out.println("\n💾 IMPORT/EXPORT DATA");
        System.out.println("🚧 Feature coming soon!");
    }
    
    private void manageBackup() {
        System.out.println("\n🗂️ BACKUP & UTILITIES");
        System.out.println("🚧 Feature coming soon!");
    }
    
    private void showReports() {
        System.out.println("\n📊 REPORTS & ANALYTICS");
        
        // Demonstrate Streams for reporting
        List<Student> topStudents = studentService.getStudentsByGpa(3.5);
        
        if (topStudents.isEmpty()) {
            System.out.println("No students with GPA ≥ 3.5 found.");
        } else {
            System.out.println("🏆 TOP STUDENTS (GPA ≥ 3.5)");
            for (int i = 0; i < topStudents.size(); i++) {
                Student student = topStudents.get(i);
                System.out.printf("%d. %s - GPA: %.2f%n", 
                    i + 1, student.getFullName(), student.calculateGPA());
            }
        }
    }
    
    private void showJavaInfo() {
        System.out.println("\n" + "═".repeat(50));
        System.out.println("ℹ️ JAVA PLATFORM INFORMATION");
        System.out.println("═".repeat(50));
        System.out.println("Java Version: " + System.getProperty("java.version"));
        System.out.println("JVM Vendor: " + System.getProperty("java.vm.vendor"));
        System.out.println("Runtime: " + System.getProperty("java.runtime.name"));
        System.out.println("OS: " + System.getProperty("os.name") + " " + System.getProperty("os.version"));
        
        System.out.println("\n📚 Java Editions Comparison:");
        System.out.println("• Java SE (Standard Edition): Desktop, server applications");
        System.out.println("• Java EE (Enterprise Edition): Enterprise-level applications");
        System.out.println("• Java ME (Micro Edition): Embedded & mobile devices");
        
        Runtime runtime = Runtime.getRuntime();
        System.out.printf("\n💻 Memory: %dMB used / %dMB total%n",
            (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024),
            runtime.totalMemory() / (1024 * 1024));
    }
    
    private void updateStudent() {
        System.out.println("\n🔄 UPDATE STUDENT");
        System.out.println("🚧 Feature coming soon!");
    }
    
    private void deactivateStudent() {
        System.out.println("\n🚫 DEACTIVATE STUDENT");
        System.out.println("🚧 Feature coming soon!");
    }
    
    private void viewStudentTranscript() {
        System.out.println("\n📄 VIEW TRANSCRIPT");
        System.out.println("🚧 Feature coming soon!");
    }
    
    private void searchCoursesByDepartment() {
        System.out.println("\n🏛️ SEARCH BY DEPARTMENT");
        System.out.println("🚧 Feature coming soon!");
    }
    
    private void searchCoursesByInstructor() {
        System.out.println("\n👨‍🏫 SEARCH BY INSTRUCTOR");
        System.out.println("🚧 Feature coming soon!");
    }
    
    // ================= UTILITY METHODS =================
    private String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    
    private int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String input = scanner.nextLine().trim();
                if (input.isEmpty()) {
                    throw new NumberFormatException("Empty input");
                }
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("❌ Please enter a valid number!");
            }
        }
    }
    
    private void shutdown() {
        System.out.println("\n" + "=".repeat(50));
        System.out.println("👋 Thank you for using " + AppConfig.APP_NAME);
        System.out.println("🕒 Session ended: " + LocalDateTime.now().format(config.getDateFormatter()));
        System.out.println("=".repeat(50));
        scanner.close();
    }
}
